from django.shortcuts import render
from .models import modelEmp

# Create your views here.
def index(request):
    return render(request,'index.html')


def add_emp(request):
    return None


def view_emp(request):
    return render(request,"vemp.html",{"data":modelEmp.objects.all()})


def view_empname(request):
    n = request.GET.get("name")
    res=modelEmp.objects.filter(name=n)
    return render(request,"view_empname.html",{"data":res})