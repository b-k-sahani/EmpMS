from django.apps import AppConfig


class EmpmanagesystemConfig(AppConfig):
    name = 'EmpManageSystem'
