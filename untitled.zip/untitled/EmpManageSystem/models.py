from django.db import models

# Create your models here.
class modelEmp(models.Model):
    name=models.CharField(max_length=100)
    cont=models.IntegerField(max_length=20)
    email=models.EmailField(max_length=100)
    Jdate=models.DateField(auto_now_add=True)
    dept=models.CharField(max_length=100)
    add=models.TextField(max_length=500)
    sal=models.IntegerField()
    photo = models.ImageField(upload_to="images/")

    def __str__(self):
        return self.name

