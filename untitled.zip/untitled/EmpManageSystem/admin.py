from django.contrib import admin
from .models import modelEmp

# Register your models here.
admin.site.register(modelEmp)
